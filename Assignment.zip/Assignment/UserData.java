
public class UserData {
    String FirstName="",FamilyName="",PostCode="",CreditCard="";
    int Balance,Credit;

    public UserData(String firstName, String familyName, String postCode, String creditCard, int balance, int credit) {
        this.FirstName = firstName;
        this.FamilyName = familyName;
        this.PostCode = postCode;
        this.CreditCard = creditCard;
        this.Balance = balance;
        this.Credit = credit;
    }
}
